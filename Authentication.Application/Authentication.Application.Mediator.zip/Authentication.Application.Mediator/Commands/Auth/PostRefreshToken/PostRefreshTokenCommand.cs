﻿namespace Authentication.Application.Mediator.Commands.Auth.PostRefreshToken;

public class PostRefreshTokenCommand : IRequest<Result>, IHandler<PostRefreshTokenCommandHandler>
{
}
